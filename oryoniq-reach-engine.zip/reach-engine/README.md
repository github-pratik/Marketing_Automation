# OryonIQ — Personal-Reach Engine

The "brain" of the OryonIQ outbound system. It finds the right GovCon people, keeps only the
reachable ones, and writes a genuinely personal opener for each from a **live market signal** —
then hands off a ready-to-send list. One engine; swap the config file and it runs for any
Visioneerit product.

---

## ▶ Run the guided demo (30 seconds, no setup)

No API keys, no accounts, no installs — just Python 3. It replays a **real run** and explains
each step as it goes.

```bash
python3 demo.py
```

Press **Enter** to move through the four stages. That's it.

> Don't have Python? On a Mac, run `python3 --version`. If it's missing, macOS will offer to
> install the developer tools — accept, then re-run.

**What you'll watch:**

| Stage | What happens | Cost |
|-------|--------------|------|
| 1 · Source | Ask Apollo who matches the target (title, location, "government contracting") | **$0 — search is free** |
| 2 · Filter | Drop anyone with no reachable email, before spending anything | **$0** |
| 3 · Personalize | OpenAI writes a specific opener for each person from the live signal | fractions of a cent |
| 4 · Output | Assemble the finished emails → `leads.csv`, ready for sending | — |

The whole point: **search wide for free, only ever pay to reveal contact data on the few worth
keeping.** That's how it uses Apollo without burning credits.

---

## ▶ Run it live on fresh leads (optional)

The demo is canned so anyone can watch it. To run the engine for real:

1. Copy the key template and add your own keys:
   ```bash
   cp .secrets.env.example .secrets.env
   # then edit .secrets.env — add your Apollo + OpenAI keys
   ```
2. Run:
   ```bash
   python3 engine.py config-oryoniq.json --limit 10             # free: source + personalize
   python3 engine.py config-oryoniq.json --limit 10 --reveal    # spend credits to reveal emails
   ```

`--reveal` (and `--verify`) only ever touch the already-filtered survivors — never the whole list.

---

## The files

| File | What it is |
|------|-----------|
| `demo.py` | the guided, no-setup walkthrough (run this first) |
| `engine.py` | the actual engine |
| `config-oryoniq.json` | the **product config** — ICP, signal, offer, sender. The agent writes these. |
| `config-visioneerit.json` | a second product — same engine, one file swapped |
| `config-template.json` | a blank, self-documenting template — copy it to start a new product |
| `.secrets.env.example` | template for your API keys (live mode only) |
| `leads.csv` / `leads.json` | the output, produced by a run |

## The config is the contract (the important part)

In production, the engine **logic runs on n8n** and travels with an **AI agent**. This Python is
the reference implementation and an offline backup. The one thing that changes per product or
campaign is the **config file**, and the agent generates it. So the config is the contract:

- **Get it right → the engine runs anything.** Swap `config-oryoniq.json` for
  `config-visioneerit.json` (or any product) and the same engine sources and personalizes for that
  product. No code change.
- **Get it wrong → nothing runs.** Every run validates the config first and refuses to launch on a
  bad one, so a malformed config never reaches a real prospect.

A valid config needs: `product`, `one_liner`, `signal`, `offer`, `cta`, `sender`, a
`personalization_prompt` containing `{first_name}` and `{company}`, and an `icp` with non-empty
`person_titles` and `person_locations`.

## How it fits the bigger picture

This is the **front half** — the research + personalization moat, and the part that's cheap and
runs today. The **sending half** plugs into `leads.csv`: **Instantly** sends the email, **Sendr**
adds the LinkedIn touch + a personalized page, **Thoughtly** places a warm call on a positive
reply — all orchestrated by **n8n**. Same engine feeds all of it.
