#!/usr/bin/env python3
"""
Personal-Reach Engine — prototype (the moat: source -> research -> personalize).

Config-driven: ONE engine, MANY products. Point it at a config file and it returns a
ready-to-send, personalized lead list. The sending layer (Instantly / Sendr / Thoughtly),
orchestrated by n8n, plugs into this output downstream.

Credit discipline (see memory: Apollo is fine, don't waste credits):
  - Apollo `mixed_people/api_search` is FREE (names, titles, has_email/has_phone flags).
    Used to SOURCE and PRE-FILTER. Costs nothing.
  - Apollo reveal (`people/match`) COSTS lead credits -> only runs with --reveal, on the
    already-filtered survivors.
  - Reoon verify only runs on revealed emails (--verify).
  - OpenAI (cheap, gpt-4.1-mini) writes the per-lead opener.

Usage:
  python3 engine.py config-oryoniq.json --limit 5                     # free: source + personalize
  python3 engine.py config-oryoniq.json --limit 25 --reveal --verify  # spend on survivors only
"""
import json, os, sys, csv, argparse, urllib.request, urllib.error

ROOT = os.path.dirname(os.path.abspath(__file__))


def find_secrets():
    """Look for .secrets.env next to this file first, then one level up."""
    for p in (os.path.join(ROOT, ".secrets.env"), os.path.join(ROOT, "..", ".secrets.env")):
        if os.path.exists(p):
            return p
    return None


def load_secrets(path):
    env = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
    return env


def http_json(url, method="GET", headers=None, body=None, timeout=60):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, {"error": e.read().decode()[:300]}
    except Exception as e:
        return 0, {"error": str(e)}


REQUIRED_STR = ("product", "one_liner", "signal", "offer", "cta", "sender", "personalization_prompt")


def validate_config(cfg):
    """The config is the CONTRACT between the agent and the engine. Returns a list of problems
    (empty = valid). This is the thing that must 'land correct' before a campaign can run."""
    errors = []
    for key in REQUIRED_STR:
        v = cfg.get(key)
        if not isinstance(v, str) or not v.strip():
            errors.append(f"'{key}' must be a non-empty string")
        elif "<" in v and ">" in v:
            errors.append(f"'{key}' still has a template placeholder — fill it in")
    icp = cfg.get("icp")
    if not isinstance(icp, dict):
        errors.append("'icp' must be an object")
    else:
        if not isinstance(icp.get("person_titles"), list) or not icp.get("person_titles"):
            errors.append("'icp.person_titles' must be a non-empty list")
        elif any("<" in str(t) and ">" in str(t) for t in icp["person_titles"]):
            errors.append("'icp.person_titles' still has template placeholders — fill them in")
        if not isinstance(icp.get("person_locations"), list) or not icp.get("person_locations"):
            errors.append("'icp.person_locations' must be a non-empty list")
    prompt = cfg.get("personalization_prompt", "")
    for token in ("{first_name}", "{company}"):
        if token not in prompt:
            errors.append(f"'personalization_prompt' must contain {token} so it fills per lead")
    return errors


def org_name(p):
    return ((p.get("organization") or {}).get("name")
            or (p.get("account") or {}).get("name")
            or p.get("organization_name") or "their firm")


def apollo_search(cfg, secrets, per_page):
    icp = cfg["icp"]
    body = {
        "person_titles": icp.get("person_titles", []),
        "person_locations": icp.get("person_locations", ["United States"]),
        "q_keywords": icp.get("q_keywords", ""),
        "page": 1, "per_page": per_page,
    }
    status, data = http_json(
        "https://api.apollo.io/api/v1/mixed_people/api_search", "POST",
        {"X-Api-Key": secrets["APOLLO_API_KEY"], "Content-Type": "application/json"}, body)
    if status != 200:
        print(f"[apollo] search failed HTTP {status}: {data}", file=sys.stderr)
        return [], None
    return data.get("people", []), data.get("total_entries")


def openai_opener(lead, cfg, secrets, model):
    task = cfg["personalization_prompt"].format(
        first_name=lead.get("first_name", "there"),
        title=lead.get("title", "(role)"),
        company=org_name(lead))
    system = ("You write sharp B2B GovCon cold-email opening lines. One or two sentences, "
              "no fluff, no em-dashes, no 'leverage/unlock/streamline'. Never invent specific "
              "facts about the company. Ground it in the SIGNAL below.\n\nSIGNAL: " + cfg.get("signal", ""))
    body = {"model": model, "temperature": 0.7,
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": task}]}
    status, data = http_json("https://api.openai.com/v1/chat/completions", "POST",
                             {"Authorization": "Bearer " + secrets["Openai_api_key"],
                              "Content-Type": "application/json"}, body)
    if status != 200:
        return f"[openai HTTP {status}: {str(data)[:120]}]"
    return data["choices"][0]["message"]["content"].strip().strip('"')


def assemble_email(lead, opener, cfg):
    fn = lead.get("first_name", "there")
    return (f"Hi {fn},\n\n{opener}\n\n{cfg['offer']}\n\n"
            f"Want the three it's surfacing for a firm like yours? {cfg['cta']}\n\n{cfg['sender']}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--limit", type=int, default=5)
    ap.add_argument("--reveal", action="store_true", help="Apollo people/match (COSTS lead credits)")
    ap.add_argument("--verify", action="store_true", help="Reoon verify revealed emails (costs Reoon credits)")
    ap.add_argument("--model", default="gpt-4.1-mini")
    args = ap.parse_args()

    cfg_path = args.config if os.path.isabs(args.config) else os.path.join(ROOT, args.config)
    cfg = json.load(open(cfg_path))
    problems = validate_config(cfg)
    if problems:
        print("Config did NOT validate — the campaign will not run until these are fixed:", file=sys.stderr)
        for pr in problems:
            print("   - " + pr, file=sys.stderr)
        sys.exit(1)
    print(f"[0 config ] {os.path.basename(cfg_path)} validated OK — safe to run")
    sec_path = find_secrets()
    if not sec_path:
        sys.exit("No .secrets.env found. Copy .secrets.env.example -> .secrets.env and add your "
                 "Apollo + OpenAI keys (see README.md).  No-key demo: python3 demo.py")
    secrets = load_secrets(sec_path)
    for k in ("APOLLO_API_KEY", "Openai_api_key"):
        if not secrets.get(k) or secrets[k].endswith("_here"):
            sys.exit(f"Missing {k} in .secrets.env (see README.md).  No-key demo: python3 demo.py")

    print(f"== {cfg['product']} · personal-reach engine ==")
    print(f"   {cfg['one_liner']}\n")

    people, total = apollo_search(cfg, secrets, per_page=max(args.limit * 2, 10))
    print(f"[1 source ] Apollo search returned {len(people)} of ~{total} matches  (FREE, 0 credits)")

    survivors = [p for p in people if p.get("has_email")][:args.limit]
    print(f"[2 filter ] kept {len(survivors)} emailable leads via free has_email flag")
    print(f"[3 person.] OpenAI ({args.model}) writing a per-lead opener...\n")

    out = []
    for i, p in enumerate(survivors, 1):
        opener = openai_opener(p, cfg, secrets, args.model)
        rec = {"first_name": p.get("first_name"), "title": p.get("title"), "company": org_name(p),
               "has_email": bool(p.get("has_email")), "has_phone": p.get("has_direct_phone"),
               "apollo_id": p.get("id"), "opener": opener, "email": assemble_email(p, opener, cfg)}
        out.append(rec)
        print(f"  lead {i}: {rec['first_name']} · {rec['title']} · {rec['company']}")
        print(f"          “{opener}”\n")

    with open(os.path.join(ROOT, "leads.json"), "w") as f:
        json.dump(out, f, indent=2)
    with open(os.path.join(ROOT, "leads.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["first_name", "title", "company", "has_email", "has_phone", "apollo_id", "opener", "email"])
        for r in out:
            w.writerow([r[k] for k in ("first_name", "title", "company", "has_email", "has_phone", "apollo_id", "opener", "email")])

    print(f"[4 output ] wrote reach-engine/leads.json + leads.csv  ({len(out)} leads)")
    print("[credits  ] Apollo: 0 spent (search only).  Reveal/verify skipped (add --reveal --verify to spend on survivors).")


if __name__ == "__main__":
    main()
